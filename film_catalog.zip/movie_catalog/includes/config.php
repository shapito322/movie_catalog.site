<?php
// Конфигурация базы данных
define('DB_HOST', 'localhost');  //хост
define('DB_USER', 'root');   //имя
define('DB_PASS', '');     //пароль
define('DB_NAME', 'movie_catalog');     //имя базы данных

// Настройки сайта
define('SITE_NAME', 'Movie Catalog');
define('SITE_URL', 'http://localhost/movie_catalog/');
?>