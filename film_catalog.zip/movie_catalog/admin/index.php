<?php
// Перенаправление на дашборд
header("Location: dashboard.php");
exit();
?>